nvcc ripple.cu -lm -lGL -lGLU -lglut -o ripple
nvcc heat.cu -lm -lGL -lGLU -lglut -o heat